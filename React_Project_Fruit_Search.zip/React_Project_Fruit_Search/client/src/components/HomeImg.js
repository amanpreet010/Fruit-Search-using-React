import React from "react";
import FruitsCard from "./FruitsCard";

const HomeImg = (props) => {
    const { allFruits, Loading } = props;
    if(!allFruits || allFruits.length === 0) {
        return <p>There is no Fruit in the list.</p>
    }

    return (
        <div className="container">
            { !Loading && 
                allFruits.map((item) => {
                    return (
                        <FruitsCard key={item.id} item={item} />
                    );
                })
            }        
        </div>
    );
}

export default HomeImg;