import React from "react";

const Error = () => {
  return (
    <div className="error-message">
      <h1>Oops! Something went wrong! No data to display</h1>
    </div>
  );
};

export default Error;
