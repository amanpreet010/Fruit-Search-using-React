import React from "react";
import { useState, useEffect } from "react";

const SearchPanel = ({ onSearch }) => {
  const [value, setValue] = useState("");
  const [fruits, setFruits] = useState([]);

  useEffect(() => {
    const fetchFruits = async () => {
      try {
        const response = await fetch("http://localhost:3500/api/fruits");
        const data = await response.json();
        const fruitName = data.map((fruit) => fruit.name);
        setFruits(fruitName);
      } catch (error) {
        console.log("error fetched fruits", error);
      }
    };
    fetchFruits();
  }, []);

  useEffect(() => {
    onSearch(value);
  }, [value, onSearch]);

  const handleChange = (event) => {
    setValue(event.target.value);
  };

  const handleSearch = (userSearch) => {
    setValue(userSearch);
    onSearch(userSearch);
  };

  return (
    <div className="wrapper">
      <div className="search-bar">
        <input
          type="text"
          value={value}
          onChange={handleChange}
          placeholder="search for your favourite fruit"
          className="searchFruit"
        />
        <button onClick={() => handleSearch(value)} className="search">
          Search
        </button>
      </div>
      <div className="dropdown">
        {fruits.length > 0 &&
          fruits
            .filter((fruit) =>
              fruit.toLowerCase().includes(value.toLowerCase())
            )
            .map((fruit, index) => (
              <div
                key={index}
                onClick={() => handleSearch(fruit)}
                className="dropdown-row"
              >
                {fruit}
              </div>
            ))
            .slice(0, 8)}
      </div>
    </div>
  );
};

export default SearchPanel;
