import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart} from '@fortawesome/free-solid-svg-icons';

const FruitsCard = (props) => {
  const { item } = props;

  const changeFavourite = () => {
    localStorage.setItem("isFavourite", JSON.stringify(item.name));
    alert("Fruit marked as favourite");
  }
  

  return (
    <div className="individual-item" key={item.id}>
      <div className="second-wrapper">
        <h1 className="fruit-name">{item.name}</h1>
        <span className="fruit-info">Calories: {item.nutritions.calories}</span>
        <br></br>
        <span className="fruit-info">Fruit Family: {item.family}</span>
        <br></br>
        <span className="fruit-info">Fruit Genus: {item.genus}</span>
        <br></br>
        <span className="fruit-info">Fruit-sugar: {item.nutritions.sugar}</span>
        <br></br>
        <span className="fruit-info">Fruit Fat: {item.nutritions.fat}</span>
      </div>
      <div className="fruit-Img">
        <img src={item.image} className="newImages" alt="fruits images" />
        <button
          className="material-symbols-sharp"
          id="makeFavourite"
          onClick={() => changeFavourite()}
        ><FontAwesomeIcon icon={faHeart} /></button>
      </div>
    </div>
  );
};

export default FruitsCard;
