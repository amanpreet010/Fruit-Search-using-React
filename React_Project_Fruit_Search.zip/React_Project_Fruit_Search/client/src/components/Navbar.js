import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="nav-bar">
      <Link to="/" className="allFruits">
        All Fruits
      </Link>
     
      <ul id="nav-list" className="right">
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/order">Fruits Orders</Link>
        </li>
        <li>
          <Link to="/family">Fruits Family</Link>
        </li>
        <li>
          <Link to="/favourite">*Favourite</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
