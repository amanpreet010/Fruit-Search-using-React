import React, { useState } from "react";
import { useEffect } from "react";

const Order = () => {
  const [fruitsOrder, setFruitsOrder] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState("");
  const [filteredFruits, setFilteredFruits] = useState("");

  useEffect(() => {
    const fetchFruits = async () => {
      try {
        const response = await fetch("http://localhost:3500/api/fruits");
        const data = await response.json();
        const fruitOrder = data.map((fruit) => fruit.order);
        setFruitsOrder(fruitOrder);
      } catch (error) {
        console.log("error fetched fruits", error);
      }
    };
    fetchFruits();
  }, []);

  useEffect(() => {
    const fetchFruits = async () => {
      try {
        const response = await fetch("http://localhost:3500/api/fruits");
        const data = await response.json();

        const filtered = data.filter((fruit) => fruit.order === selectedOrder);
        setFilteredFruits(filtered);
      } catch (error) {
        console.log("Error fetching fruits", error);
      }
    };

    if (selectedOrder) {
      fetchFruits();
    }
  }, [selectedOrder]);

  const handleClick = (event) => {
    setSelectedOrder(event.target.value);
  };

  return (
    <div className="order-class">
      <select
        name="fruit-order"
        className="orders"
        onChange={handleClick}
        value={selectedOrder}
      >
        <option value="">Select an fruit order</option>

        {fruitsOrder.length > 0 &&
          fruitsOrder.map((order) => <option value={order}>{order}</option>)}
      </select>

      <div className="filtered-fruits">
        {filteredFruits.length > 0 ? (
          filteredFruits.map((fruit) => (
            <div className="individual-item" key={fruit.id}>
              <div className="second-wrapper">
                <h1 className="fruit-name">{fruit.name}</h1>
                <span className="fruit-info">
                  Calories: {fruit.nutritions.calories}
                </span>
                <br></br>
                <span className="fruit-info">Fruit Family: {fruit.family}</span>
                <br></br>
                <span className="fruit-info">Fruit Genus: {fruit.genus}</span>
                <br></br>
                <span className="fruit-info">
                  Fruit-sugar: {fruit.nutritions.sugar}
                </span>
                <br></br>
                <span className="fruit-info">
                  Fruit Fat: {fruit.nutritions.fat}
                </span>
              </div>
              <div className="fruit-Img">
                <img
                  src={fruit.image}
                  className="newImages"
                  alt="fruits images"
                />
              </div>
            </div>
          ))
        ) : (
          <p>No Fruits to display for the selected order</p>
        )}
      </div>
    </div>
  );
};

export default Order;
