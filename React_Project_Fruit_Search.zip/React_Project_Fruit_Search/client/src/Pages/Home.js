import React from "react";
import axios from "axios";
import { useState, useEffect } from "react";
import HomeImg from "../components/HomeImg";
import SearchPanel from "../components/SearchPanel";

function Home() {
  const [appState, setAppState] = useState({
    loading: false,
    fruits: null,
  });

  const [searchFruit, setSearchFruit] = useState("");

  useEffect(() => {
    async function fetchData() {
      setAppState({ loading: true, fruits: null });
      const apiURL = "http://localhost:3500/api/fruits";
      const res = await axios.get(apiURL);
      console.log(res);
      setAppState({ loading: false, fruits: res.data });
    }
    fetchData();
  }, [setAppState]);

  const handleSearch = (fruit) => {
    setSearchFruit(fruit);
  };

  const filteredFruits = appState.fruits
    ? appState.fruits.filter((fruit) =>
        fruit.name.toLowerCase().includes(searchFruit.toLowerCase())
      )
    : [];

  return (
    <div>
      <SearchPanel onSearch={handleSearch} />
      <HomeImg
        loading={appState.loading}
        allFruits={filteredFruits}
        className="wholePage"
      />
    </div>
  );
}

export default Home;
