import React, { useEffect, useState } from "react";

const Family = () => {
  const [fruitsFamily, setFruitFamily] = useState("");
  const [filteredFruits, setFilteredFruit] = useState([]);
  const [selectedFamily, setSelectedFamily] = useState("");

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch("http://localhost:3500/api/fruits");
        const data = await response.json();
        const familites = data.map((fruits) => fruits.family);
        setFruitFamily(familites);
      } catch (error) {
        console.log("error fetched fruits", error);
      }
    }
    fetchData();
  }, []);

  useEffect(() => {
    async function compareData() {
      try {
        const response = await fetch("http://localhost:3500/api/fruits");
        const data = await response.json();
        const fruitFam = data.filter(
          (fruit) => fruit.family === selectedFamily
        );
        setFilteredFruit(fruitFam);
      } catch (error) {
        console.log("error fetching data");
      }
    }

    if (selectedFamily) {
      compareData();
    }
  }, [selectedFamily]);

  const handleClick = (event) => {
    setSelectedFamily(event.target.value);
  };

  return (
    <div className="order-class">
      <select
        name="select"
        value={selectedFamily}
        onChange={handleClick}
        className="orders"
      >
        <option value="">Select a fruit family</option>

        {fruitsFamily.length > 0 &&
          fruitsFamily.map((order) => <option value={order}>{order}</option>)}
      </select>
      <div className="filtered-fruits">
        {filteredFruits.length > 0 ? (
          filteredFruits.map((fruit) => (
            <div className="individual-item" key={fruit.id}>
              <div className="second-wrapper">
                <h1 className="fruit-name">{fruit.name}</h1>
                <span className="fruit-info">
                  Calories: {fruit.nutritions.calories}
                </span>
                <br></br>
                <span className="fruit-info">Fruit Family: {fruit.family}</span>
                <br></br>
                <span className="fruit-info">Fruit Genus: {fruit.genus}</span>
                <br></br>
                <span className="fruit-info">
                  Fruit-sugar: {fruit.nutritions.sugar}
                </span>
                <br></br>
                <span className="fruit-info">
                  Fruit Fat: {fruit.nutritions.fat}
                </span>
              </div>
              <div className="fruit-Img">
                <img
                  src={fruit.image}
                  className="newImages"
                  alt="fruits images"
                />
              </div>
            </div>
          ))
        ) : (
          <p>No family is found with this family</p>
        )}
      </div>
    </div>
  );
};

export default Family;
