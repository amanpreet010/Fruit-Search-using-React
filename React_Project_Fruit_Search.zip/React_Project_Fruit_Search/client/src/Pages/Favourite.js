import { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";

const Favourite = () => {
  const [getFavourite, setFavourite] = useState("");

  useEffect(() => {
    const favourite = localStorage.getItem("isFavourite");
    if (favourite) {
      setFavourite(JSON.parse(favourite));
    } else {
      setFavourite("There is no Favourite fruit set by the user");
    }
  }, []);

  const deleteFavourite = () => {
    localStorage.removeItem("isFavourite");
    setFavourite("There is no Favourite fruit set by the user"); // Update state after deletion
    alert("Fruit deleted from the favourite");
  };

  return (
    <div className="favour">
      <button className="trash" onClick={deleteFavourite}>
        <FontAwesomeIcon icon={faTrash} />
      </button>
      <h4 className="favourite-text">Favourite Fruits: {getFavourite}</h4>
    </div>
  );
};

export default Favourite;
