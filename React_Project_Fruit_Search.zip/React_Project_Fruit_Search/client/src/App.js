import React from "react";
import Home from "./Pages/Home";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Navbar from "./components/Navbar";
import Order from "./Pages/Order"
import Family from "./Pages/Family";
import Favourite from "./Pages/Favourite";
import Error from './components/Error';

function App() {
  return (
    <div>
      <Router>
        <Navbar />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/order" component={Order} />
          <Route exact path="/family" component={Family} />
          <Route path="/favourite" component={Favourite} />
          <Route component={Error} />

        </Switch>
      </Router>
    </div>
  );
}

export default App;
