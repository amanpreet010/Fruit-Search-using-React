const express = require("express");
const router = express.Router();
const fruits = require("../../Fruits");

router.get("/", (req, res) => res.json(fruits));

/*
router.get("/api/fruits/:id", (req, res) => {
  const found = fruits.some((fruit) => fruit.id === parseInt(req.params.id));

  if (found) {
    res.json(fruits.filter((fruit) => fruit.id === parseInt(req.params.id)));
  } else {
    res.status(400).json({ id: `No fruit with the id of ${req.params.id}` });
  }
});

router.post("/", (req, res) => {
  const newFruit = {
    id: req.body.id,
    name: req.body.name,
    family: req.body.family,
  };

  if (!newFruit.name || !newFruit.family) {
    return res
      .status(400)
      .json({ msg: `Please provide the full information of the fruit` });
  }
  fruits.push(newFruit);
  res.json(fruits);
});

//update members

router.put(":/id", (req, res) => {
  const found = fruits.some((fruit) => fruit.id === parseInt(req.params.id));

  if (found) {
    const updatedMember = req.body;
    fruits.forEach((fruit) => {
      if (fruit.id === parseInt(req.params.id)) {
        fruit.name = updatedMember.name ? updatedMember.name : fruit.name;
        fruit.family = updatedMember.family
          ? updatedMember.family
          : fruit.family;
      }
    });
  }
});

*/

//making get, put, post and delete request

router.post("/", (req, res) => {
  const newFruit = {
    name: req.body.name,
    family: req.body.family,
    order: req.body.order,
  };

  if (!newFruit.name || !newFruit.family || !newFruit.order) {
    return res
      .status(400)
      .json({ msg: `provide all the informaiton of the fruit` });
  }

  fruits.push(newFruit);
  res.json(fruits);
});

router.put(":/id", (req, res) => {
  const found = fruits.some((fruit) => fruit.id === parseInt(req.params.id));

  if (found) {
    const updatedmember = req.body;
    fruits.forEach((fruit) => {
      if (fruit.id === parseInt(req.params.id)) {
        name: updatedmember.name ? updatedmember.name : fruit.name;
        family: updatedmember.family ? updatedmember.family : fruit.family;
        order: updatedmember.order ? updatedmember.order : fruit.order;
      }
    });
  } else {
    res.json({ msg: `No member with the id ${req.params.id} exist` });
  }
});

router.delete("/:id", (req, res) => {
  const found = fruits.some(fruit => fruit.id === parseInt(req.params.id));

  if (found) {
    res.json({
      msg: `Member deleted`,
      fruits: fruits.filter((fruit) => fruit.id !== parseInt(req.params.id))
    });
  } else {
    res.json({ msg: `No fruit with the id ${req.params.id} exists` });
  }
});

module.exports = router;
