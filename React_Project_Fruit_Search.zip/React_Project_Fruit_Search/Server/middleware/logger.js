//middleware are basicall functions that excess the request object and respnse object and the next function object
//what can we do inside hte function
///can exclude any request acll the next middleware in the request
const logger = (req, res, next) => {
    console.log(`${req.protocol}://${req.get('host')}${req.originalUrl}`);
    next();
}

module.exports = logger;