const express = require('express');
const logger = require('./middleware/logger');
const fruits = require('./Fruits');

const app = express();

// Initialize the middleware
app.use(logger);
app.use(express.json());
app.use(express.urlencoded({extended: false}));

app.use('/api/fruits', require('./routes/api/fruits'));

const PORT = 3500;

app.listen(PORT, () => console.log(`Server started on port ${PORT}!!!`));


/*
in the index.js file we are just having the responsees which will be given to the user based on the request


*/